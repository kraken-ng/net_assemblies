# BadPotato

Windows 2012-2019


Windows 8-10

![](https://raw.githubusercontent.com/BeichenDream/BadPotato/master/screen.png)

## 引用


[https://github.com/vletoux/pingcastle](https://github.com/vletoux/pingcastle "pingcastle")


[https://itm4n.github.io/printspoofer-abusing-impersonate-privileges/](https://itm4n.github.io/printspoofer-abusing-impersonate-privileges/ "PrintSpoofer")
