﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dummy
{
    class Program
    {
        public string call(string[] args)
        {
            return string.Join("<space>", args);
        }

        static void Main(string[] args)
        {
            Program pro = new Program();
            Console.WriteLine(pro.call(args));
        }
    }
}
