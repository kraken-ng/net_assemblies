﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dummy
{
    class Program
    {
        public string call(string[] args)
        {
            return string.Join("<space>", args);
        }

        public static void Main(string[] args)
        {
            Program pro = new Program();
            Console.WriteLine(pro.call(args));
        }
    }
}
